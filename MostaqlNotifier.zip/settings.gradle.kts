rootProject.name = "MostaqlNotifier"
include(":app")
